#!/usr/bin/env bash
set -euo pipefail
HUGO_VERSION=0.152.2
curl -sLJO https://github.com/gohugoio/hugo/releases/download/v\( {HUGO_VERSION}/hugo_extended_ \){HUGO_VERSION}_linux-amd64.tar.gz
mkdir -p $HOME/.local/hugo
tar -C \( HOME/.local/hugo -xf hugo_extended_ \){HUGO_VERSION}_linux-amd64.tar.gz
export PATH="$HOME/.local/hugo:$PATH"
hugo --gc --minify --baseURL "https://${VERCEL_PROJECT_PRODUCTION_URL}/"